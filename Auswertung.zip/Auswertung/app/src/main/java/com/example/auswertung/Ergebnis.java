package com.example.auswertung;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Ergebnis extends AppCompatActivity {
    int endergebnis = 0;
    double schnitt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ergebnis);

        TextView text = findViewById(R.id.tv1);
        TextView text2 = findViewById(R.id.tv2);

        Intent intent = getIntent();
        int [] ringe = intent.getIntArrayExtra(MainActivity.ergebnis);
        int schuss = intent.getIntExtra(MainActivity.schuss, 0);

        StringBuilder gesamt = new StringBuilder();
        for(int i = 0; i<40; i++){
            if(i==0){
                gesamt.append("1.Serie: \n");
            }
            if(i==10){
                gesamt.append("2.Serie: \n");
            }
            if(i==20){
                gesamt.append("3.Serie: \n");
            }
            if(i==30){
                gesamt.append("4.Serie: \n");
            }
            gesamt.append(i+1).append(". Schuss: ").append(ringe[i]).append("\n");
            endergebnis = endergebnis + ringe[i];
        }

        schnitt = (double) endergebnis / (double) schuss;

        text.setText(gesamt);
        text2.setText("Gesamt: " + Integer.toString(endergebnis) + "  Schnitt: " + Double.toString(schnitt) + "  Schüsse: " + Integer.toString(schuss));
    }
}
